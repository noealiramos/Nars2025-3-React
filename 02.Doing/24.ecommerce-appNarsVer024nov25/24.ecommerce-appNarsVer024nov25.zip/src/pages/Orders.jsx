import "./Orders.css";

export default function Orders() {
  return (
    <div className="orders-page">
      <h1>Mis pedidos</h1>
    </div>
  );
}
