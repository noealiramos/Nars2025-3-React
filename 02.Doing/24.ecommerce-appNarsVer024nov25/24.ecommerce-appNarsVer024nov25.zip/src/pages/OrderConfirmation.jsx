import { useLocation, useNavigate } from "react-router-dom";
import "./OrderConfirmation.css";

export default function OrderConfirmation() {
  const location = useLocation();
  const navigate = useNavigate();
  const { order } = location.state || {};

  return (
    <div className="order-confirmation">
      <h1>Order Confirmation</h1>
      {order.date}
    </div>
  );
}
