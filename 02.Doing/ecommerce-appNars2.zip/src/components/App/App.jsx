import Layout from "../../layout/Layout";
import BannerCarousel from "../BannerCarousel/BannerCarousel";

function App() {
  const images = [
    {
      title: "Nuevas colecciones de verano",
      subtitle: "Descubre nuevas tendencias en moda",
      image:
        "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1200&h=600&fit=crop",
      buttonText: "Ver colección",
      buttonLink: "/collections/summer",
      backgroundColor: "#26336c",
    },
    {
      title: "Ofertas Especiales",
      subtitle: "Hasta 50% de descuento en productos seleccionados",
      image:
        "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1200&h=600&fit=crop",
      buttonText: "Ver Ofertas",
      buttonLink: "/offers",
      backgroundColor: "#8677b5",
    },
    {
      title: "Tecnología Innovadora",
      subtitle: "Los últimos gadgets y dispositivos electrónicos",
      image:
        "https://images.unsplash.com/photo-1468495244123-6c6c332eeece?w=1200&h=600&fit=crop",
      buttonText: "Explorar",
      buttonLink: "/tech",
      backgroundColor: "#3eb7ea",
    },
    {
      title: "Envío Gratis",
      subtitle: "En compras superiores a $50",
      image:
        "https://images.unsplash.com/photo-1607083206869-4c7672e72a8a?w=1200&h=600&fit=crop",
      buttonText: "Comprar Ahora",
      buttonLink: "/free-shipping",
      backgroundColor: "#79bf87",
    },
  ];

  function click() {
    alert("OK");
  }

  return (
    <Layout>
      <BannerCarousel banners={images} />
    </Layout>
  );
}

export default App;
