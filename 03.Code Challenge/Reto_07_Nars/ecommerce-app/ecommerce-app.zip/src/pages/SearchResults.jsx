import SearchResultsList from "../components/SearchResultsList/SearchResultsList";

export default function SearchResults() {
  return <SearchResultsList />;
}
