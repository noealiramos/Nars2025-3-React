export default function WishList() {}
